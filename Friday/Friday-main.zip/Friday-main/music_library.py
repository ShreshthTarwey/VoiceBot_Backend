music = {
    "awarapan" : "https://youtu.be/-rePN9cxfaQ?si=NEFWFQtqvSW6oSPm" ,
    "hale dil" : "https://youtu.be/ZuMLl7BI6D4?si=tb94JLwCDRKZB5j7&t=11" ,
    "woh lamhe" : "https://youtu.be/y12BRDS1CHI?si=DA8OGqudsbhkCS-A",
    "zara sa" : "https://youtu.be/ZsAOnmByy38?si=CuxSO6HLy1-6X4-l" ,
    "tu hi mera" : "https://youtu.be/yBa3FVQKAvY?si=nhWEoe56mx_E7e7p" ,
    "shera" : "https://youtu.be/knGCfzm4jWs?si=9IAVDr9AoI8447VK" ,
    "najar ka teer" : "https://youtu.be/cehyr946p64?si=oo-755CNWldNu-cR" ,
    "bulleya" : "https://youtu.be/a9Hxkc9YxGE?si=smgSKmH9atzHY17T&t=11" ,
    "safari" : "https://youtu.be/lpeuIu-ZYJY?si=5nW5YT0vbdNNTgLQ",
    "haseen" : "https://youtu.be/wCTmWy43HgM?si=j8D9xdYCydAMvCWL"
}